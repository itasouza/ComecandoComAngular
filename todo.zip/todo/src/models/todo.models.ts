export class Todo {
    constructor(
        public id: Number = 1,
        public title: String,
        public done: Boolean
    ) { }
}
